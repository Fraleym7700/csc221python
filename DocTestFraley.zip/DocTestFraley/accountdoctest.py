# accountdoctest.py
from decimal import Decimal

class Account:
    """Account class for demonstrating doctest."""
    
    def __init__(self, name, balance):
        """Initialize an Account object.
        
        >>> account1 = Account('John Green', Decimal('50.00'))
        >>> account1.name
        'John Green'
        >>> account1.balance
        Decimal('50.00')
        
        The balance argument must be greater than or equal to 0.
        >>> account2 = Account('John Green', Decimal('-50.00'))
        Traceback(most recent call last):
            ...
        ValueError: Initial balance must be >= to 0.00.


        Deposit money to the account.
        >>> account3 = Account('John Green', Decimal('50.00'))
        >>> account3.deposit(Decimal('10.55'))
        >>> account3.balance
        Decimal('60.55')
        
        >>> account1.deposit(Decimal('-100.00'))
        Traceback(most recent call last):
            ...
        ValueError: amount must be positive.
 
        >>> account4 = Account("", Decimal('50.00'))
        >>> account4.name
        ""
        Traceback(most recent call last):
            ...
        ValueError: Name cannot be empty value.
        
        WithDraw money to the account.
        >>> account5 = Account('John Green', Decimal('50.00'))
        >>> account5.withdraw(Decimal('10.00'))
        >>> account5.balance
        Decimal('40.00')
        
        >>> account1.withdraw(Decimal('-100.00'))
        Traceback(most recent call last):
            ...
        ValueError: amount must be positive.
        
        """
        #if balance is less than 0.00, raise an exception
        if balance < Decimal('0.00'):
            raise ValueError('Initial balance must be >= to 0.00.')
        
        if name == "":
            raise ValueError('Name cannot be empty value.')
        self.name = name
        self.balance = balance
        
    def deposit(self, amount):
        """Deposit money to the account"""
        
        #If amount is less than 0.00 raise an exception
        if amount < Decimal('0.00'):
            raise ValueError('amount must be positive.')
            
        self.balance += amount
        
    def withdraw(self, amount):
        
        """WithDraw money to the account"""
        
        #If amount is less than 0.00 raise an exception
        if amount < Decimal('0.00'):
            raise ValueError('amount must be positive.')
            
        self.balance -= amount
        
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)